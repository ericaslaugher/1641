print('hello python')

a = input('Enter a: ')
b = input('Enter b: ')
if a > b:
    print('Max = ', a)
else:
    print('Max = ', b)